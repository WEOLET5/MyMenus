package my.mymenus.listeners;

import my.mymenus.Command;
import my.mymenus.Menu;
import my.mymenus.utils.HexUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;

import java.util.Map;
import java.util.UUID;

public class InventoryListener implements Listener {
    private final Command command;

    public InventoryListener(Command command) {
        this.command = command;
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        Player player = (Player) event.getPlayer();
        UUID uuid = player.getUniqueId();
        Map<UUID, Menu> activeSessions = command.getActiveSessions();

        Menu session = activeSessions.get(uuid);
        if (session != null) {
            player.sendMessage(HexUtil.color("&aМеню '&f" + session.getMenuName() + "&2' Успешно сохранено"));
            player.sendMessage(HexUtil.color("&fВыберите действие:"));
            player.sendMessage(HexUtil.color("&2/mymenus save &7- Пренудительное сохранение"));
        }
    }
}