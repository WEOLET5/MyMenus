package my.mymenus.listeners;

import my.mymenus.Command;
import my.mymenus.Menu;
import my.mymenus.utils.HexUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;

import java.util.UUID;

public class InventoryClickListener implements Listener {
    private final Command command;

    public InventoryClickListener(Command command) {
        this.command = command;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        UUID uuid = player.getUniqueId();
        Menu session = command.getActiveSessions().get(uuid);

        if (session == null || event.getClickedInventory() == null) return;
        if (!event.getClickedInventory().equals(session.getInventory())) return;

        if (event.getClick().isRightClick() && event.getSlotType() != InventoryType.SlotType.OUTSIDE) {
            event.setCancelled(true);
            player.closeInventory();

            int slot = event.getSlot();
            command.setActionEditing(player, slot);
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            player.sendMessage(HexUtil.color("&fРедактор действий предмета в слоте &2" + slot));
            player.sendMessage(HexUtil.color("&2Введите команду:"));
            player.sendMessage(HexUtil.color("&f/mymenus action add " + slot + " (left/right/shiftleft/shiftright) [player/console/sound/close/open/message] (аргументы)"));
            player.sendMessage(HexUtil.color("&f/mymenus action remove " + slot + " (left/right/shiftleft/shiftright) (команда)"));
            player.sendMessage(HexUtil.color("&f/mymenus action list"));
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
        }
    }
}