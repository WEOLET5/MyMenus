package my.mymenus.listeners;

import my.mymenus.Command;
import my.mymenus.ItemAction;
import my.mymenus.Menu;
import my.mymenus.utils.HexUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class ChatListener implements Listener {
    private final Command command;

    public ChatListener(Command command) {
        this.command = command;
    }

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        Integer slot = command.getActionEditing().get(uuid);

        if (slot == null) {
            return;
        }

        event.setCancelled(true);
        String message = event.getMessage().trim();

        if (!message.startsWith("/mymenus action")) {
            player.sendMessage(HexUtil.color("&fИспользуйте команду: /mymenus action ..."));
            return;
        }

        Menu session = command.getActiveSessions().get(uuid);
        if (session == null) {
            player.sendMessage(HexUtil.color("&fСначала выберите меню с помощью /mymenus sel (меню)"));
            command.clearActionEditing(player);
            return;
        }

        String[] args = message.split(" ");
        if (args.length < 3 || !args[1].equalsIgnoreCase("action")) {
            sendActionHelp(player, slot);
            return;
        }

        switch (args[2].toLowerCase()) {
            case "add":
                if (args.length < 6) {
                    sendActionHelp(player, slot);
                    return;
                }
                try {
                    int actionSlot = Integer.parseInt(args[3]);
                    if (actionSlot != slot) {
                        player.sendMessage(HexUtil.color("&fВы редактируете слот " + slot + ", а не " + actionSlot + "!"));
                        return;
                    }
                } catch (NumberFormatException e) {
                    player.sendMessage(HexUtil.color("&fСлот должен быть числом"));
                    return;
                }
                String clickType = args[4].toLowerCase();
                if (!List.of("left", "right", "shiftleft", "shiftright").contains(clickType)) {
                    player.sendMessage(HexUtil.color("&fНедопустимый тип клика! Используйте: left, right, shiftleft, shiftright"));
                    return;
                }
                String actionType = args[5].toLowerCase();
                String arguments = String.join(" ", Arrays.copyOfRange(args, 6, args.length));
                String commandStr = actionType + " " + arguments;

                session.addItemAction(slot, clickType, new ItemAction(clickType, commandStr));
                player.sendMessage(HexUtil.color("&aДействие добавлено для слота " + slot + " (" + clickType + "): " + commandStr));
                command.saveMenu(player, false);
                break;

            case "remove":
                if (args.length < 5) {
                    sendActionHelp(player, slot);
                    return;
                }
                try {
                    int actionSlot = Integer.parseInt(args[3]);
                    if (actionSlot != slot) {
                        player.sendMessage(HexUtil.color("&fВы редактируете слот " + slot + ", а не " + actionSlot + "!"));
                        return;
                    }
                } catch (NumberFormatException e) {
                    player.sendMessage(HexUtil.color("&fСлот должен быть числом"));
                    return;
                }
                clickType = args[4].toLowerCase();
                commandStr = String.join(" ", Arrays.copyOfRange(args, 5, args.length));
                session.removeItemAction(slot, clickType, commandStr);
                player.sendMessage(HexUtil.color("&aДействие удалено для слота " + slot + " (" + clickType + "): " + commandStr));
                command.saveMenu(player, false);
                break;

            case "list":
                player.sendMessage(HexUtil.color("&fДействия для слота " + slot + " в меню '" + session.getMenuName() + "':"));
                if (session.getItemActions().containsKey(slot)) {
                    session.getItemActions().get(slot).forEach((clickTypeKey, actionList) -> {
                        actionList.forEach(action -> {
                            player.sendMessage(HexUtil.color("&2  " + clickTypeKey + ": " + action.getCommand()));
                        });
                    });
                } else {
                    player.sendMessage(HexUtil.color("&fНет действий для этого слота."));
                }
                break;

            default:
                sendActionHelp(player, slot);
        }
    }

    private void sendActionHelp(Player player, int slot) {
        player.sendMessage(HexUtil.color("&fРедактор действий предмета для слота &2" + slot));
        player.sendMessage(HexUtil.color("&2Введите команду:"));
        player.sendMessage(HexUtil.color("&f/mymenus action add " + slot + " (left/right/shiftleft/shiftright) [player/console/sound/close/open/message] (аргументы)"));
        player.sendMessage(HexUtil.color("&f/mymenus action remove " + slot + " (left/right/shiftleft/shiftright) (команда)"));
        player.sendMessage(HexUtil.color("&f/mymenus action list"));
    }
}