package my.mymenus;

import org.bukkit.inventory.Inventory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Menu {
    private final String menuName;
    private final String fileName;
    private final String title;
    private final int size;
    private final Inventory inventory;
    private final Map<Integer, Map<String, List<ItemAction>>> itemActions;

    public Menu(String menuName, String fileName, String title, int size, Inventory inventory) {
        this.menuName = menuName;
        this.fileName = fileName;
        this.title = title;
        this.size = size;
        this.inventory = inventory;
        this.itemActions = new HashMap<>();
    }

    public String getMenuName() {
        return menuName;
    }

    public String getFileName() {
        return fileName;
    }

    public String getTitle() {
        return title;
    }

    public int getSize() {
        return size;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public Map<Integer, Map<String, List<ItemAction>>> getItemActions() {
        return itemActions;
    }

    public void addItemAction(int slot, String clickType, ItemAction action) {
        itemActions.computeIfAbsent(slot, k -> new HashMap<>())
                .computeIfAbsent(clickType, k -> new ArrayList<>())
                .add(action);
    }

    public void removeItemAction(int slot, String clickType, String command) {
        if (itemActions.containsKey(slot) && itemActions.get(slot).containsKey(clickType)) {
            itemActions.get(slot).get(clickType).removeIf(action -> action.getCommand().equals(command));
            if (itemActions.get(slot).get(clickType).isEmpty()) {
                itemActions.get(slot).remove(clickType);
            }
            if (itemActions.get(slot).isEmpty()) {
                itemActions.remove(slot);
            }
        }
    }
}