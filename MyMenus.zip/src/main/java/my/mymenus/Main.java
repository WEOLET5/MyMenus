package my.mymenus;

import my.mymenus.listeners.ChatListener;
import my.mymenus.listeners.InventoryClickListener;
import my.mymenus.listeners.InventoryListener;
import my.mymenus.utils.ConfigUtil;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public final class Main extends JavaPlugin {
    private ConfigUtil configUtil;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        configUtil = new ConfigUtil(getConfig());

        File menusFolder = new File(configUtil.getSaveFolder());
        if (!menusFolder.exists()) {
            menusFolder.mkdirs();
        }

        Command menusCommand = new Command(this);
        getCommand("mymenus").setExecutor(menusCommand);
        getCommand("mymenus").setTabCompleter(menusCommand);
        getServer().getPluginManager().registerEvents(new InventoryListener(menusCommand), this);
        getServer().getPluginManager().registerEvents(new InventoryClickListener(menusCommand), this);
        getServer().getPluginManager().registerEvents(new ChatListener(menusCommand), this);

        getLogger().info("      §2MyMenus §fv1.0.1");
        getLogger().info("     - Успешно запущен!");
    }

    public ConfigUtil getConfigUtil() {
        return configUtil;
    }

    public File getMenusFolder() {
        return new File(configUtil.getSaveFolder());
    }
}