package my.mymenus.utils;

import org.bukkit.configuration.file.FileConfiguration;

public final class ConfigUtil {
    private final FileConfiguration config;

    public ConfigUtil(FileConfiguration config) {
        this.config = config;
    }

    public String getSaveFolder() {
        return config.getString("save-menus-to", "plugins/MyMenus/menus");
    }
}