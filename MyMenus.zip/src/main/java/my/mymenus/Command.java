package my.mymenus;

import my.mymenus.utils.HexUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class Command implements CommandExecutor, TabCompleter {
    private final Main plugin;
    private final Map<UUID, Menu> activeSessions = new HashMap<>();
    private final Map<UUID, Integer> actionEditing = new HashMap<>();
    private final File menusFolder;

    public Command(Main plugin) {
        this.plugin = plugin;
        this.menusFolder = plugin.getMenusFolder();
    }

    public void setActionEditing(Player player, int slot) {
        actionEditing.put(player.getUniqueId(), slot);
    }

    public void clearActionEditing(Player player) {
        actionEditing.remove(player.getUniqueId());
    }

    public Map<UUID, Integer> getActionEditing() {
        return actionEditing;
    }

    @Override
    public boolean onCommand(CommandSender sender, org.bukkit.command.Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(HexUtil.color("&fЭта команда только для игроков!"));
            return true;
        }

        if (!player.hasPermission("mymenus.use")) {
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            player.sendMessage(HexUtil.color("&fУ вас нет права использовать эту команду!"));
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "create":
                if (args.length != 3) {
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                    player.sendMessage(HexUtil.color("&fИспользование: /mymenus create (название) (размер)"));
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                    return true;
                }
                handleCreate(player, args[1], args[2]);
                break;

            case "edit":
                if (args.length == 2) {
                    handleEdit(player, args[1]);
                } else if (args.length >= 4 && args[2].equalsIgnoreCase("title")) {
                    String newTitle = String.join(" ", Arrays.copyOfRange(args, 3, args.length));
                    handleEditTitle(player, args[1], newTitle);
                } else {
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                    player.sendMessage(HexUtil.color("&fИспользование: /mymenus edit (меню) [title (новый_заголовок)]"));
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                }
                break;

            case "delete":
                if (args.length != 2) {
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                    player.sendMessage(HexUtil.color("&fИспользование: /mymenus delete (меню)"));
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                    return true;
                }
                handleDelete(player, args[1]);
                break;

            case "save":
                saveMenu(player, true);
                break;

            case "action":
                if (args.length < 2) {
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                    player.sendMessage(HexUtil.color("&fИспользование: /mymenus action add (слот) (clickType) [player/console/sound/close/open/message] (аргументы)"));
                    player.sendMessage(HexUtil.color("&fили /mymenus action remove (слот) (clickType) (команда)"));
                    player.sendMessage(HexUtil.color("&fили /mymenus action list"));
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▐"));
                    return true;
                }
                handleActionCommand(player, args);
                break;

            case "sel":
                if (args.length != 2) {
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                    player.sendMessage(HexUtil.color("&fИспользование: /mymenus sel (меню)"));
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                    return true;
                }
                handleSelect(player, args[1]);
                break;

            default:
                sendHelp(player);
        }
        return true;
    }

    private void handleActionCommand(Player player, String[] args) {
        UUID uuid = player.getUniqueId();
        Menu session = activeSessions.get(uuid);
        if (session == null) {
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            player.sendMessage(HexUtil.color("&fСначала выберите меню с помощью /mymenus sel (меню)!"));
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            return;
        }

        if (args[1].equalsIgnoreCase("add")) {
            if (args.length < 4) {
                player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                player.sendMessage(HexUtil.color("&fИспользование: /mymenus action add (слот) (clickType) [player/console/sound/close/open/message] (аргументы)"));
                player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                return;
            }

            int slot;
            try {
                slot = Integer.parseInt(args[2]);
                if (slot < 0 || slot >= session.getSize()) {
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                    player.sendMessage(HexUtil.color("&fНедопустимый слот! Должен быть от 0 до " + (session.getSize() - 1)));
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                    return;
                }
            } catch (NumberFormatException e) {
                player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                player.sendMessage(HexUtil.color("&fСлот должен быть числом!"));
                player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                return;
            }

            String clickType = args[3].toLowerCase();
            if (!List.of("left", "right", "shiftleft", "shiftright").contains(clickType)) {
                player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                player.sendMessage(HexUtil.color("&fНедопустимый тип клика! Используйте: left, right, shiftleft, shiftright"));
                player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                return;
            }

            String actionType = args[4].toLowerCase();
            String arguments = String.join(" ", Arrays.copyOfRange(args, 5, args.length));
            String commandStr = actionType + " " + arguments;

            setActionEditing(player, slot);
            session.addItemAction(slot, clickType, new ItemAction(clickType, commandStr));
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            player.sendMessage(HexUtil.color("&aДействие добавлено для слота " + slot + " (" + clickType + "): " + commandStr));
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            saveMenu(player, false);
        } else if (args[1].equalsIgnoreCase("remove")) {
            if (args.length < 4) {
                player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                player.sendMessage(HexUtil.color("&fИспользование: /mymenus action remove (слот) (clickType) (команда)"));
                player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                return;
            }

            int slot;
            try {
                slot = Integer.parseInt(args[2]);
                if (slot < 0 || slot >= session.getSize()) {
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                    player.sendMessage(HexUtil.color("&fНедопустимый слот! Должен быть от 0 до " + (session.getSize() - 1)));
                    player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                    return;
                }
            } catch (NumberFormatException e) {
                player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                player.sendMessage(HexUtil.color("&fСлот должен быть числом!"));
                player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                return;
            }

            String clickType = args[3].toLowerCase();
            String commandStr = String.join(" ", Arrays.copyOfRange(args, 4, args.length));
            session.removeItemAction(slot, clickType, commandStr);
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            player.sendMessage(HexUtil.color("&aДействие удалено для слота " + slot + " (" + clickType + "): " + commandStr));
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            saveMenu(player, false);
        } else if (args[1].equalsIgnoreCase("list")) {
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            player.sendMessage(HexUtil.color("&fДействия для меню '" + session.getMenuName() + "':"));
            session.getItemActions().forEach((slot, actions) -> {
                player.sendMessage(HexUtil.color("&fСлот " + slot + ":"));
                actions.forEach((clickType, actionList) -> {
                    actionList.forEach(action -> {
                        player.sendMessage(HexUtil.color("&2  " + clickType + ": " + action.getCommand()));
                    });
                });
            });
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
        } else {
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            player.sendMessage(HexUtil.color("&fИспользование: /mymenus action add (слот) (clickType) [player/console/sound/close/open/message] (аргументы)"));
            player.sendMessage(HexUtil.color("&fили /mymenus action remove (слот) (clickType) (команда)"));
            player.sendMessage(HexUtil.color("&fили /mymenus action list"));
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
        }
    }

    private void handleSelect(Player player, String menuName) {
        File file = new File(menusFolder, menuName + ".yml");
        if (!file.exists()) {
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            player.sendMessage(HexUtil.color("&fМеню '&f" + menuName + "&f' не найдено!"));
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        String title = config.getString("menu_title", menuName).replace("'", "");
        int size = config.getInt("size", 27);
        Inventory inv = Bukkit.createInventory(null, size, "Редактирование меню: " + menuName);

        Menu menu = new Menu(menuName, file.getName(), title, size, inv);

        if (config.contains("items")) {
            for (String key : config.getConfigurationSection("items").getKeys(false)) {
                int slot = config.getInt("items." + key + ".slot");
                ItemStack item = new ItemStack(
                        org.bukkit.Material.valueOf(config.getString("items." + key + ".material")));
                item.setAmount(config.getInt("items." + key + ".amount", 1));
                int data = config.getInt("items." + key + ".data", 0);
                if (data > 0) {
                    item.setDurability((short) data);
                }
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    if (config.contains("items." + key + ".display_name")) {
                        meta.setDisplayName(HexUtil.color(
                                config.getString("items." + key + ".display_name").replace("'", "")));
                    }
                    if (config.contains("items." + key + ".lore")) {
                        List<String> lore = new ArrayList<>();
                        for (String line : config.getStringList("items." + key + ".lore")) {
                            lore.add(HexUtil.color(line.replace("'", "")));
                        }
                        meta.setLore(lore);
                    }
                    item.setItemMeta(meta);
                }
                if (slot >= 0 && slot < size) {
                    inv.setItem(slot, item);
                }

                String[] clickTypes = {"left", "right", "shiftleft", "shiftright"};
                for (String clickType : clickTypes) {
                    String path = "items." + key + "." + clickType + "_click_commands";
                    if (config.contains(path)) {
                        for (String cmd : config.getStringList(path)) {
                            menu.addItemAction(slot, clickType, new ItemAction(clickType, cmd));
                        }
                    }
                }
            }
        }

        activeSessions.put(player.getUniqueId(), menu);
        player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
        player.sendMessage(HexUtil.color("&aМеню '&f" + menuName + "&a' выбрано для редактирования."));
        player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            completions.addAll(Arrays.asList("create", "edit", "delete", "save", "action", "sel"));
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("edit") || args[0].equalsIgnoreCase("delete") || args[0].equalsIgnoreCase("sel")) {
                File[] files = menusFolder.listFiles((dir, name) -> name.endsWith(".yml"));
                if (files != null) {
                    completions.addAll(Arrays.stream(files)
                            .map(file -> file.getName().replace(".yml", ""))
                            .collect(Collectors.toList()));
                }
            } else if (args[0].equalsIgnoreCase("action")) {
                completions.addAll(Arrays.asList("add", "remove", "list"));
            }
        } else if (args.length == 3) {
            if (args[0].equalsIgnoreCase("create")) {
                completions.addAll(Arrays.asList("9", "18", "27", "36", "45", "54"));
            } else if (args[0].equalsIgnoreCase("edit")) {
                completions.add("title");
            } else if (args[0].equalsIgnoreCase("action") && (args[1].equalsIgnoreCase("add") || args[1].equalsIgnoreCase("remove"))) {
                if (sender instanceof Player player) {
                    Menu session = activeSessions.get(player.getUniqueId());
                    if (session != null) {
                        for (int i = 0; i < session.getSize(); i++) {
                            completions.add(String.valueOf(i));
                        }
                    }
                }
            }
        } else if (args.length == 4 && args[0].equalsIgnoreCase("action") && (args[1].equalsIgnoreCase("add") || args[1].equalsIgnoreCase("remove"))) {
            completions.addAll(Arrays.asList("left", "right", "shiftleft", "shiftright"));
        } else if (args.length == 5 && args[0].equalsIgnoreCase("action") && args[1].equalsIgnoreCase("add")) {
            completions.addAll(Arrays.asList("player", "console", "sound", "close", "open", "message"));
        }

        return completions;
    }

    private void sendHelp(Player player) {
        player.sendMessage(HexUtil.color("&f&lMyMenus &a- Создание меню"));
        player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
        player.sendMessage(HexUtil.color("&f/mymenus create (название) (размер) &2- Создать новое меню (9, 18, 27, 36, 45, 54)"));
        player.sendMessage(HexUtil.color("&f/mymenus sel (меню) &2- Выбрать меню для редактирования"));
        player.sendMessage(HexUtil.color("&f/mymenus edit (меню) &2- Редактировать существующее меню"));
        player.sendMessage(HexUtil.color("&f/mymenus edit (меню) title (заголовок) &2- Изменить заголовок меню"));
        player.sendMessage(HexUtil.color("&f/mymenus delete (меню) &2- Удалить меню"));
        player.sendMessage(HexUtil.color("&f/mymenus save &2- Сохранить текущее меню"));
        player.sendMessage(HexUtil.color("&f/mymenus action add (слот) (clickType) [player/console/sound/close/open/message] (аргументы) &2- Добавить действие для предмета"));
        player.sendMessage(HexUtil.color("&f/mymenus action remove (слот) (clickType) (команда) &2- Удалить действие для предмета"));
        player.sendMessage(HexUtil.color("&f/mymenus action list &2- Показать действия меню"));
        player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
    }

    private void handleCreate(Player player, String menuName, String sizeStr) {
        String fileName = menuName + ".yml";
        int size;
        try {
            size = Integer.parseInt(sizeStr);
            if (size != 9 && size != 18 && size != 27 && size != 36 && size != 45 && size != 54) {
                player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                player.sendMessage(HexUtil.color("&fРазмер должен быть 9, 18, 27, 36, 45, 54"));
                player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                return;
            }
        } catch (NumberFormatException e) {
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            player.sendMessage(HexUtil.color("&fРазмер должен быть числом!"));
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            return;
        }

        File file = new File(menusFolder, fileName);
        if (file.exists()) {
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            player.sendMessage(HexUtil.color("&fМеню '&f" + menuName + "&f' уже существует!"));
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            return;
        }

        Inventory inv = Bukkit.createInventory(null, size, "Создание меню: " + menuName);
        player.openInventory(inv);
        activeSessions.put(player.getUniqueId(), new Menu(menuName, fileName, menuName, size, inv));
        player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
        player.sendMessage(HexUtil.color("&aСоздание меню '&f" + menuName + "&a' начато. Поместите предметы и закройте инвентарь."));
        player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
    }

    private void handleEdit(Player player, String menuName) {
        File file = new File(menusFolder, menuName + ".yml");
        if (!file.exists()) {
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            player.sendMessage(HexUtil.color("&fМеню '&f" + menuName + "&f' не найдено!"));
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        String title = config.getString("menu_title", menuName).replace("'", "");
        int size = config.getInt("size", 27);
        Inventory inv = Bukkit.createInventory(null, size, "Редактирование меню: " + menuName);

        Menu menu = new Menu(menuName, file.getName(), title, size, inv);

        if (config.contains("items")) {
            for (String key : config.getConfigurationSection("items").getKeys(false)) {
                int slot = config.getInt("items." + key + ".slot");
                ItemStack item = new ItemStack(
                        org.bukkit.Material.valueOf(config.getString("items." + key + ".material")));
                item.setAmount(config.getInt("items." + key + ".amount", 1));
                int data = config.getInt("items." + key + ".data", 0);
                if (data > 0) {
                    item.setDurability((short) data);
                }
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    if (config.contains("items." + key + ".display_name")) {
                        meta.setDisplayName(HexUtil.color(
                                config.getString("items." + key + ".display_name").replace("'", "")));
                    }
                    if (config.contains("items." + key + ".lore")) {
                        List<String> lore = new ArrayList<>();
                        for (String line : config.getStringList("items." + key + ".lore")) {
                            lore.add(HexUtil.color(line.replace("'", "")));
                        }
                        meta.setLore(lore);
                    }
                    item.setItemMeta(meta);
                }
                if (slot >= 0 && slot < size) {
                    inv.setItem(slot, item);
                }

                String[] clickTypes = {"left", "right", "shiftleft", "shiftright"};
                for (String clickType : clickTypes) {
                    String path = "items." + key + "." + clickType + "_click_commands";
                    if (config.contains(path)) {
                        for (String cmd : config.getStringList(path)) {
                            menu.addItemAction(slot, clickType, new ItemAction(clickType, cmd));
                        }
                    }
                }
            }
        }

        player.openInventory(inv);
        activeSessions.put(player.getUniqueId(), menu);
        player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
        player.sendMessage(HexUtil.color("&aРедактирование меню '&f" + menuName + "&a' начато."));
        player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
    }

    private void handleEditTitle(Player player, String menuName, String newTitle) {
        File file = new File(menusFolder, menuName + ".yml");
        if (!file.exists()) {
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            player.sendMessage(HexUtil.color("&fМеню '&f" + menuName + "&f' не найдено!"));
            player.sendMessage(HexUtil.color("&2&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        config.set("menu_title", HexUtil.color(newTitle));
        try {
            config.save(file);
            player.sendMessage(HexUtil.color("&aЗаголовок меню '&f" + menuName + "&a' изменен на '&f" + newTitle + "&a'!"));
        } catch (IOException e) {

            player.sendMessage(HexUtil.color("&fОшибка при сохранении меню"));
        }
    }

    private void handleDelete(Player player, String menuName) {
        File file = new File(menusFolder, menuName + ".yml");
        if (!file.exists()) {
            player.sendMessage(HexUtil.color("&fМеню '&f" + menuName + "&f' не найдено!"));
            return;
        }

        if (file.delete()) {
            player.sendMessage(HexUtil.color("&aМеню '&f" + menuName + "&a' удалено!"));
        } else {
            player.sendMessage(HexUtil.color("&fНе удалось удалить меню"));
        }
    }

    public void saveMenu(Player player, boolean showMessage) {
        UUID uuid = player.getUniqueId();
        Menu session = activeSessions.get(uuid);
        if (session == null) {
            if (showMessage) {
                player.sendMessage(HexUtil.color("&fНет меню для сохранения"));
            }
            return;
        }

        File file = new File(menusFolder, session.getFileName());
        YamlConfiguration config = new YamlConfiguration();

        config.set("menu_title", HexUtil.color(session.getTitle()));
        config.set("open_command", session.getMenuName().toLowerCase());
        config.set("size", session.getSize());

        ItemStack[] items = session.getInventory().getContents();
        for (int i = 0; i < items.length; i++) {
            if (items[i] != null && items[i].getType() != org.bukkit.Material.AIR) {
                String itemId = "item_" + i;
                config.set("items." + itemId + ".material", items[i].getType().name());
                config.set("items." + itemId + ".slot", i);
                config.set("items." + itemId + ".amount", items[i].getAmount());
                if (items[i].getDurability() > 0) {
                    config.set("items." + itemId + ".data", items[i].getDurability());
                }
                ItemMeta meta = items[i].getItemMeta();
                if (meta != null) {
                    if (meta.hasDisplayName()) {
                        config.set("items." + itemId + ".display_name",
                                meta.getDisplayName().replace("§", "&"));
                    }
                    if (meta.hasLore()) {
                        List<String> lore = new ArrayList<>();
                        for (String line : meta.getLore()) {
                            lore.add(line.replace("§", "&"));
                        }
                        config.set("items." + itemId + ".lore", lore);
                    }
                }

                if (session.getItemActions().containsKey(i)) {
                    for (String clickType : session.getItemActions().get(i).keySet()) {
                        List<String> commands = new ArrayList<>();
                        for (ItemAction action : session.getItemActions().get(i).get(clickType)) {
                            commands.add(action.getCommand());
                        }
                        config.set("items." + itemId + "." + clickType + "_click_commands", commands);
                    }
                }
            }
        }

        try {
            config.save(file);
            if (showMessage) {
                player.sendMessage(HexUtil.color("&aМеню '&f" + session.getMenuName() + "&a' сохранено в '&f" + session.getFileName() + "&a'!"));
            }
            activeSessions.remove(uuid);
            actionEditing.remove(uuid);
        } catch (IOException e) {
            if (showMessage) {
                player.sendMessage(HexUtil.color("&fОшибка при сохранении меню"));
            }
        }
    }

    public Map<UUID, Menu> getActiveSessions() {
        return activeSessions;
    }
}