package my.mymenus;

public class ItemAction {
    private final String clickType;
    private final String command;

    public ItemAction(String clickType, String command) {
        this.clickType = clickType;
        this.command = command;
    }

    public String getClickType() {
        return clickType;
    }

    public String getCommand() {
        return command;
    }
}